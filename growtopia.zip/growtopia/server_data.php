server|139.162.50.228
port|17119
type|1
#maint|`2Maintance

beta_server|52.53.171.232
beta_port|17119

beta_type|1
meta|localhost
